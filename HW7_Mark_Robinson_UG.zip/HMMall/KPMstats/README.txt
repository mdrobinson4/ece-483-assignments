KPMstats is a directory of miscellaneous statistics functions written by
Kevin Patrick Murphy and various other people (see individual file headers).


